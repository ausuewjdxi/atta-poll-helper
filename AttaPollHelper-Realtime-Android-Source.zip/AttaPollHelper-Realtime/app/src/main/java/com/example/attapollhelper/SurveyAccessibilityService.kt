package com.example.attapollhelper

import android.accessibilityservice.AccessibilityService
import android.graphics.PixelFormat
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.view.Gravity
import android.view.View
import android.view.WindowManager
import android.view.accessibility.AccessibilityEvent
import android.view.accessibility.AccessibilityNodeInfo
import android.widget.Button
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView

class SurveyAccessibilityService : AccessibilityService() {
    private var windowManager: WindowManager? = null
    private var panel: View? = null
    private var questionView: TextView? = null
    private var adviceView: TextView? = null
    private var shown = false
    private var lastText = ""

    override fun onServiceConnected() {
        super.onServiceConnected()
        windowManager = getSystemService(WINDOW_SERVICE) as WindowManager
    }

    override fun onAccessibilityEvent(event: AccessibilityEvent?) {
        if (event == null) return
        val pkg = event.packageName?.toString().orEmpty()
        // Safety boundary: only operate in AttaPoll. The package name may differ by app version/region.
        if (!pkg.contains("attapoll", ignoreCase = true)) {
            hidePanel()
            return
        }
        val root = rootInActiveWindow ?: return
        val text = StringBuilder()
        collectText(root, text, 0)
        val screenText = text.toString().trim().take(5000)
        if (screenText == lastText) return
        lastText = screenText
        val question = findQuestion(screenText)
        if (question.isBlank()) {
            hidePanel()
        } else {
            showPanel(question)
        }
    }

    private fun collectText(node: AccessibilityNodeInfo?, out: StringBuilder, depth: Int) {
        if (node == null || depth > 18 || out.length > 5000) return
        val t = node.text?.toString()?.trim().orEmpty()
        val d = node.contentDescription?.toString()?.trim().orEmpty()
        if (t.isNotBlank() && out.indexOf(t) < 0) out.append(t).append('\n')
        if (d.isNotBlank() && d != t && out.indexOf(d) < 0) out.append(d).append('\n')
        for (i in 0 until node.childCount) collectText(node.getChild(i), out, depth + 1)
    }

    private fun findQuestion(all: String): String {
        val lines = all.lines().map { it.trim() }.filter { it.length >= 8 }
        val candidate = lines.firstOrNull {
            it.contains("?") ||
            listOf("how often", "how old", "which of", "do you", "have you", "what is", "what are", "how many", "when did", "would you", "in the last").any { key ->
                it.contains(key, ignoreCase = true)
            }
        } ?: return ""
        return candidate.take(450)
    }

    private fun adviceFor(question: String): String {
        val profile = getSharedPreferences("helper", MODE_PRIVATE).getString("profile", "").orEmpty().trim()
        val lower = question.lowercase()
        val tip = when {
            listOf("age", "how old", "date of birth").any { lower.contains(it) } ->
                "Choose your real age or age range."
            listOf("work", "employed", "occupation", "job").any { lower.contains(it) } ->
                "Choose your current work situation accurately."
            listOf("buy", "purchase", "shopping", "brand").any { lower.contains(it) } ->
                "Answer from your actual purchases and habits, not what you think they want."
            listOf("often", "frequency", "how many times").any { lower.contains(it) } ->
                "Think about the time period stated and estimate honestly."
            listOf("opinion", "think", "prefer", "satisfied").any { lower.contains(it) } ->
                "Choose the option that matches your own view."
            else -> "Read all options and choose the one that truthfully fits you. If unsure, use a genuine 'not sure' option if available."
        }
        val profileNote = if (profile.isNotBlank()) "\nYour saved facts are available in the app; compare them with the question before answering." else "\nYou can add your genuine facts in Survey Helper to remind yourself."
        return tip + profileNote + "\n\nSuggestion only — you choose the answer."
    }

    private fun showPanel(question: String) {
        if (panel == null) createPanel()
        questionView?.text = "Question detected:\n$question"
        adviceView?.text = adviceFor(question)
        if (!shown) {
            try {
                windowManager?.addView(panel, layoutParams())
                shown = true
            } catch (_: Exception) { }
        }
    }

    private fun createPanel() {
        val container = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(16, 14, 16, 14)
            background = GradientDrawable().apply {
                setColor(0xFFF8FAFC.toInt())
                cornerRadius = 24f
                setStroke(2, 0xFFCBD5E1.toInt())
            }
            elevation = 10f
        }
        val header = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
        }
        header.addView(TextView(this).apply {
            text = "Survey Helper"
            textSize = 16f
            setTypeface(null, Typeface.BOLD)
            setTextColor(0xFF172033.toInt())
        }, LinearLayout.LayoutParams(0, -2, 1f))
        header.addView(Button(this).apply {
            text = "Hide"
            setOnClickListener { hidePanel() }
        })
        container.addView(header)
        val scroll = ScrollView(this)
        val body = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(0, 8, 0, 0)
        }
        questionView = TextView(this).apply {
            textSize = 15f
            setTextColor(0xFF111827.toInt())
            setPadding(0, 0, 0, 8)
        }
        adviceView = TextView(this).apply {
            textSize = 14f
            setTextColor(0xFF334155.toInt())
        }
        body.addView(questionView)
        body.addView(adviceView)
        scroll.addView(body)
        container.addView(scroll, LinearLayout.LayoutParams(-1, 220))
        panel = container
    }

    private fun layoutParams() = WindowManager.LayoutParams(
        (resources.displayMetrics.widthPixels * 0.92f).toInt(),
        WindowManager.LayoutParams.WRAP_CONTENT,
        WindowManager.LayoutParams.TYPE_ACCESSIBILITY_OVERLAY,
        WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN,
        PixelFormat.TRANSLUCENT
    ).apply {
        gravity = Gravity.BOTTOM or Gravity.CENTER_HORIZONTAL
        y = (resources.displayMetrics.heightPixels * 0.08f).toInt()
    }

    private fun hidePanel() {
        if (shown && panel != null) {
            try { windowManager?.removeView(panel) } catch (_: Exception) { }
            shown = false
        }
    }

    override fun onInterrupt() { hidePanel() }

    override fun onDestroy() {
        hidePanel()
        panel = null
        super.onDestroy()
    }
}
