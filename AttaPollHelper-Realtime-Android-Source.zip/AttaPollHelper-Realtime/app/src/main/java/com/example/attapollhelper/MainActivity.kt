package com.example.attapollhelper

import android.app.Activity
import android.content.Intent
import android.os.Bundle
import android.provider.Settings
import android.view.Gravity
import android.view.ViewGroup
import android.widget.Button
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast

class MainActivity : Activity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val prefs = getSharedPreferences("helper", MODE_PRIVATE)
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(24, 28, 24, 24)
            gravity = Gravity.TOP
        }
        root.addView(TextView(this).apply {
            text = "Survey Helper"
            textSize = 26f
            setTextColor(0xFF172033.toInt())
        })
        root.addView(TextView(this).apply {
            text = "Real-time screen reader prototype"
            textSize = 15f
            setPadding(0, 4, 0, 18)
        })
        root.addView(TextView(this).apply {
            text = "Your genuine facts (optional). Use only details that are true for you; the helper stores this on this phone."
            textSize = 14f
        })
        val profile = EditText(this).apply {
            hint = "e.g. age range, work status, hobbies, shopping habits"
            minLines = 3
            gravity = Gravity.TOP
            setText(prefs.getString("profile", ""))
        }
        root.addView(profile, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT))
        root.addView(Button(this).apply {
            text = "Save my facts"
            setOnClickListener {
                prefs.edit().putString("profile", profile.text.toString()).apply()
                Toast.makeText(this@MainActivity, "Saved on this phone", Toast.LENGTH_SHORT).show()
            }
        })
        root.addView(TextView(this).apply {
            text = "\nTo turn on real-time reading:\n1. Tap the button below.\n2. Open Survey Helper in Accessibility settings.\n3. Turn it on and approve the permission.\n4. Open AttaPoll. The helper only displays suggestions; it never chooses or submits answers."
            textSize = 14f
        })
        root.addView(Button(this).apply {
            text = "Open Accessibility settings"
            setOnClickListener { startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS)) }
        })
        root.addView(TextView(this).apply {
            text = "\nPrivacy: visible screen text may contain sensitive information. This prototype processes text locally and does not send it to a server. Turn the service off when you are not using it."
            textSize = 12f
            setPadding(0, 16, 0, 0)
        })
        setContentView(root)
    }
}
