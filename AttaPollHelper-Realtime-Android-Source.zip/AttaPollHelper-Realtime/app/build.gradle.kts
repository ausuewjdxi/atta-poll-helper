plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}
android {
    namespace = "com.example.attapollhelper"
    compileSdk = 35
    defaultConfig {
        applicationId = "com.example.attapollhelper"
        minSdk = 26
        targetSdk = 35
        versionCode = 2
        versionName = "0.2-realtime"
    }
}
dependencies {
    implementation("androidx.core:core-ktx:1.15.0")
}
