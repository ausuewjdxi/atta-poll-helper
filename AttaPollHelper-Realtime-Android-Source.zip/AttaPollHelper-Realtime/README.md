# Survey Helper — real-time Android prototype

This prototype uses Android Accessibility to read visible text **locally on your phone** and show a small overlay with truth-focused guidance. It does not tap, choose, or submit answers.

## Important limits
- This is a prototype, not a finished/tested release.
- The AttaPoll Android package name can differ. The service currently checks for a package name containing `attapoll`; if the installed app uses a different package ID, the service may need adjustment.
- Some screens use custom rendering and may not expose text to Android Accessibility, so they may not be readable.
- The guidance is rule-based, not a full AI model. It cannot reliably select the correct answer for arbitrary survey questions.
- Keep the Accessibility service off except while using the helper; it can read visible screen text in the target app.
- Do not use fabricated personal information. Review every suggestion and answer truthfully.

## Build without a computer (cloud route)
The included GitHub Actions workflow builds a debug APK in the cloud. A GitHub repository is required:
1. Create a new repository on GitHub.
2. Upload the project files (not just this ZIP) to the repository, keeping the `.github/workflows/android.yml` path.
3. Open the repository's **Actions** tab and run **Build Android APK** (or push to `main`).
4. Open the completed workflow run and download the `Survey-Helper-debug-APK` artifact. GitHub may require the artifact to be downloaded and extracted.
5. Install the APK on your Samsung phone. Android may ask you to allow installs from the browser or file manager used to open it.
6. Open Survey Helper → Open Accessibility settings → enable Survey Helper screen reader.

Cloud building is not the same as testing. Test only on your own phone first and disable Accessibility when finished.
